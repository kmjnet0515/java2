import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionTest03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		try {
			System.out.print("첫 번째 수 입력 : ");
			int num1 = stdIn.nextInt();
			System.out.print("두 번째 수 입력 : ");
			int num2 = stdIn.nextInt();
				System.out.println("두 수의 나눗셈 결과 : " + ((double)num1 / num2));
		}
		catch(ArithmeticException e){
			System.out.println(e);
			//e.printStackTrace();
		}
		catch(InputMismatchException e1) {
			System.out.println(e1);
		}
		catch(NumberFormatException e2) {
			System.out.println(e2);
		}
		catch(Exception e4) {
			System.out.println(e4);
		}
		finally {
			System.out.println("예외처리 테스트");
		}
		stdIn.close();
	}
}
