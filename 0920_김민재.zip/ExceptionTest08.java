/*
 * 
 * 나이를 입력받아 출력하시오. 
 * 입력 받은 나이가 정수가 아닐 경우 예외처리 하시오. 
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionTest08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		try {
			System.out.println("나이를 입력하세요. (정수)");
			int num1 = stdIn.nextInt();
			System.out.println("나이는 : " + num1 + "입니다.");
		}
		catch(InputMismatchException e) {
			System.out.println(e);
		}
	}

}
