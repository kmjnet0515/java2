/*
 * 
 * a.txt 파일 정보 출력. 
 */
import java.io.File;
public class FileDirTest02 {

	public static void main(String[] args) {
		try {
			File f1 = new File("/Users/macbook/Library/Mobile Documents/com~apple~CloudDocs/교내활동/대학/2학년2학기/java/Chapter13/src/b.txt");
			System.out.println("파일 이름 : " + f1.getName());
			System.out.println("파일 경로 : " + f1.getPath());
			System.out.println(f1.exists() ? "파일 존재" : "파일 없음");
			System.out.println("파일 크기 : " + f1.length() + "Bytes");
		}
		catch(Exception e) {
			System.out.println("파일이 아니거나 존재하지 않습니다. ");
		}
	}

}
