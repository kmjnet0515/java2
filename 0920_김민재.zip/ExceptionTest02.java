import java.util.Scanner;

public class ExceptionTest02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.print("첫 번째 수 입력 : ");
		int num1 = stdIn.nextInt();
		System.out.print("두 번째 수 입력 : ");
		int num2 = stdIn.nextInt();
		try {
			System.out.println("두 수의 나눗셈 결과 : " + (num1 / num2));
		}
		catch(Exception e){
			System.out.println(e);
			//e.printStackTrace();
		}
		finally {
			System.out.println("예외처리 테스트");
		}
	}

}
