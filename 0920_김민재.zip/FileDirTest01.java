/*
 * 
 * Windows 디렉토리에 대한 내용 출력 
 * File 객체 사용.
 */
import java.io.File;
public class FileDirTest01 {

	public static void main(String[] args) {
		String directory = "/Users/macbook/Library/Mobile Documents/com~apple~CloudDocs/교내활동/대학/2학년2학기";
		try {
			File f1 = new File(directory);
			System.out.println("검색 디렉토리 : " + directory);
			String s[] = f1.list();
			for(int i = 0; i<s.length; i++) {
				File f = new File(directory + "/" + s[i]);
				if(f.isDirectory()) {
					System.out.println(s[i] + " 디렉토리");
				}
				else if(s[i].charAt(0) == '.'){
					System.out.println(s[i] + " 숨김 파일");
				}
				else {
					System.out.println(s[i] + " 파일");
				}
			}
		}
		catch(Exception e) {
			System.out.println("디렉토리가 아니거나 존재하지 않습니다. ");
		}
	}

}
