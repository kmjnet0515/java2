/*
 * 작성일 : 9월 11일 
 * 작성자 : 202395006 김민재 
 * 설명 : 예제 11.4
 * 
 * 다음 프로그램은 세 개의 클래그사 상속 관계에 있으면서 하나의 속성과 하나의 메소드를 가지고 있습니다.
 * 객체 지향 언어와 다형성(polymorphism)을 제공하는 예시 
 */
class Am{
	static int count = 1; // 속성
	static void callme() { //메소드
		System.out.println("Am의 callme() 실행, count 값 : " + count);
	}
}
class Bm extends Am{   
	static int count = 2; // 속성
	static void callme2() { //메소드
		System.out.println("Bm의 callme() 실행, count 값 : " + count);
	}
}
class Cm extends Am{
	static int count = 3; // 속성
	static void callme() { //메소드
		System.out.println("Cm의 callme() 실행, count 값 : " + count);
	}
}
public class PolymorphismTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//다향성에서 기본적으로 앞쪽에 오는 class에 기능과 속성을 사용하지만 생성자가 하위클래스이고 메서드 오버라이딩이 되어있다면 쓸 수 있다. 
		//속성은 오버라이딩이 되지 않는다. 
		Am r = new Am();
		r.callme();
		System.out.println("r.count 값 : " + r.count);
		
		r = new Bm();
		r.callme();
		System.out.println("r.count 값 : " + r.count);
		
		r = new Cm();
		r.callme();
		System.out.println("r.count 값 : " + r.count);
	}

}
