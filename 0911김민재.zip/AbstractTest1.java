abstract class Shape{
	abstract void draw();
	abstract void computeArea(double a, double b);
}
class Rectangle1 extends Shape{
	void draw() {
		System.out.println("사각형을 그리는 기능");
		
	}
	void computeArea(double h, double v) {
		System.out.println("사각형의 넓이  : " + (h*v));
	}
}
public class AbstractTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s = new Rectangle1();
		s.draw();
	}

}
