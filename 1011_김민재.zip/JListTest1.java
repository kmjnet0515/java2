import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
class EventClass10 implements ListSelectionListener{
	private JList jlist1;
	ImageIcon[] fruitIcons;
	JLabel[] jlicon;
	String[] fruitsList;
	JLabel jlname;
	public EventClass10(JList jlist1, ImageIcon[] fruitIcons, JLabel[] jlicon, String[] fruitsList, JLabel jlname) {
		this.jlist1 = jlist1;
		this.fruitIcons = fruitIcons;
		this.jlicon = jlicon;
		this.fruitsList = fruitsList;
		this.jlname = jlname;
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		for(int i = 0; i<fruitIcons.length; i++) {
			jlicon[i].setIcon(null);
		}
		//리스트의 내용 가져오기. 
		int[] indices = jlist1.getSelectedIndices();
		String s = "당신이 선택한 항목은 : ";
		
		//리스트 반복하면서 
		for(int i = 0; i<indices.length; i++) {
			//과일 아이콘 리스트의 이미지를 가져온다. 
			jlicon[i].setIcon(fruitIcons[indices[i]]);
			//과일 이름 가져오기 
			s += fruitsList[indices[i]] + " ";
			
		}
		jlname.setText(s);
	}
	
}
class JListTest extends JFrame{
	//과일 배열 
	private String fruitsList[]= {
			"apple",
			"banana",
			"cherry",
			"grape",
			"pear",
			"persimmom"
	};
	//과일 리스트 객체 생성.
	private JList jlist1 = new JList(fruitsList);
	
	private ImageIcon[] fruitIcons = {
		new ImageIcon("image/apple.jpg"),
		new ImageIcon("image/banana.jpg"),
		new ImageIcon("image/cherry.jpg"),
		new ImageIcon("image/grape.jpg"),
		new ImageIcon("image/pear.jpg"),
		new ImageIcon("image/persimmom.jpg"),
	};
	
	//이미지 아이콘과 과일 이름 출력 라벨
	private JLabel[] jlicon = new JLabel[6];
	private JLabel jlname = new JLabel();
	public JListTest() {
		Container ct1  = getContentPane();
		//동서남북 배치가 가능한 레이아웃 
		ct1.setLayout(new BorderLayout());
		
		//이미지 영역 
		JPanel jp1 = new JPanel();
		jp1.setLayout(new GridLayout(3,2,5,5));
		
		//그리드에 아이콘 붙이기 
		for(int i = 0; i<fruitsList.length; i++) {
			jp1.add(jlicon[i] = new JLabel());
		}
		//과일 이름 출력 영역 
		JPanel jp2 = new JPanel();
		jp2.add(jlname);
		
		ct1.add(jlist1, BorderLayout.WEST);
		ct1.add(jp1, BorderLayout.CENTER);
		ct1.add(jp2, BorderLayout.EAST);
		
		jlist1.addListSelectionListener(new EventClass10(jlist1, fruitIcons, jlicon, fruitsList, jlname));
		
		
		
		setTitle("JListTest");
		
		setSize(700,300);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
	}
}
public class JListTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JListTest();
	}

}
