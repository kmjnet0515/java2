import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

class EventClass8 implements ActionListener{
	JCheckBox jc[];
	JRadioButton jrb;
	JLabel jl3;
	int i;
	String[] hobby;
	public EventClass8(JCheckBox jc[], JRadioButton jrb, int i, JLabel jl3, String[] hobby) {
		this.jc = jc;
		this.jrb = jrb;
		this.i = i;
		this.jl3 = jl3;
		this.hobby = hobby;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String s = "당신의 취미는 : ";
		for(int k = 0; k<5; k++) {
			if(jc[k].isSelected()) {
				s = s + hobby[k] + ", ";
			}
		}
		s = s + " | 당신의 나이는 : ";
		jl3.setText(s + e.getActionCommand());
	}
	
}

class JRadioButton1 extends JFrame{
	public JRadioButton1() {
		Container ct1 = getContentPane();
		ct1.setLayout(new GridLayout(4,1));
		JPanel jp1 = new JPanel();
		JPanel jp2 = new JPanel();
		JPanel hobbyPanel = new JPanel();
		JPanel agePanel = new JPanel();

		JLabel jl1 = new JLabel("당신의 취미는? ");
		JLabel jl2 = new JLabel("당신의 나이는? ");
		JLabel jl3 = new JLabel();
		
		String[] hobby = {"등산", "책읽기", "게임하기", "영화보기", "노래방가기"};
		String[] age = {"20대", "30대", "40대", "50대", "60대"};
		
		JCheckBox[] jc = new JCheckBox[5];
		JRadioButton[] jrb = new JRadioButton[5];
		ButtonGroup gb = new ButtonGroup();
		//취미와 나이를 나타내는 체크박스와 라디오 버튼 객체를 배열로 생성. 
		for(int i = 0; i<5;i++) {
			jc[i] = new JCheckBox(hobby[i]);
			jrb[i] = new JRadioButton(age[i]);
			
			hobbyPanel.add(jc[i]);
			agePanel.add(jrb[i]);
			//이벤트 만들기. 
			jrb[i].addActionListener(new EventClass8(jc, jrb[i], i, jl3, hobby));
			gb.add(jrb[i]);
			
		}
		jp1.add(jl1);
		jp1.add(hobbyPanel);
		jp2.add(jl2);
		jp2.add(agePanel);
		
		//결과 
		JPanel jp3 = new JPanel();
		
		jp3.add(jl3);
		ct1.add(jp1);
		ct1.add(jp2);
		ct1.add(jp3);
		
		
		setTitle("JRadioButtonTest1");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
	}
}
public class JRadioButtonTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JRadioButton1();
	}

}
