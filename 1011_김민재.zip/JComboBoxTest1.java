import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
class EventClass9 implements ItemListener{
	String fruitList[];
	JLabel jl;
	public EventClass9(String fruitList[], JLabel jl) {
		this.fruitList = fruitList;
		this.jl = jl;
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		String fruit = (String)e.getItem();
		jl.setIcon(new ImageIcon("image/" + fruit + ".jpg"));
	}
	
}
class JComboBox1 extends JFrame{
	
	public JComboBox1() {
		Container ct = getContentPane();
		JLabel jl = new JLabel();
		ct.setLayout(new FlowLayout());
		
		//콤보박스 객체 생성.
		JComboBox<String> fruitCombo = new JComboBox<String>();
		
		//콤보박스에 들어갈 내용이면서 이미지 파일명을 배열로 선언. 
		String fruitsList[]= {
			"apple",
			"banana",
			"cherry",
			"grape",
			"pear",
			"persimmom"
		};
		
		for(int i = 0; i<fruitsList.length; i++) {
			fruitCombo.addItem(fruitsList[i]);
		}
		fruitCombo.addItemListener(new EventClass9(fruitsList, jl));
		
		ct.add(fruitCombo);
		ct.add(jl);
		
		setTitle("JComboBox");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
	}
}
public class JComboBoxTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JComboBox1();
	}

}
