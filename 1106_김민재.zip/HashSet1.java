import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

public class HashSet1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<Integer> odd = new HashSet<Integer>();
		HashSet<Integer> even = new HashSet<Integer>();
		for(int i = 1; i<= 10; i+=2) {
			odd.add(i);
			even.add(i + 1);
		}
		System.out.println(odd);
		System.out.println(even);
		
		boolean setChanged = odd.add(5);
		System.out.println(setChanged);
		
		System.out.println(odd);
		System.out.println(even);
		
		setChanged = even.add(12);
		System.out.println(setChanged);
		
		System.out.println(odd);
		System.out.println(even);
		
		//최대 최소값 찾기 
		System.out.println(Collections.min(odd));
		System.out.println(Collections.max(even));
		
		// Iterator 객체를 제네릭으로 생성. 
		Iterator<Integer> evenIt = even.iterator();
		int sum = 0;
		while(evenIt.hasNext()) {
			sum += evenIt.next();
		}
		System.out.println("합 : " + sum);
		
		Iterator<Integer> oddIt = odd.iterator();
		sum = 0;
		while(oddIt.hasNext()) {
			sum += oddIt.next();
		}
		System.out.println("합 : " + sum);
		
		
		

	}

}
