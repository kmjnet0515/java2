import java.util.LinkedList;
import java.util.TreeSet;

public class TreeSetTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Integer> num1 = new TreeSet<Integer>();
		TreeSet<Integer> num2 = new TreeSet<Integer>();
		
		LinkedList<Integer> num3 = new LinkedList<Integer>();
		LinkedList<Integer> num4 = new LinkedList<Integer>();

		System.out.println("--------------- TreeSet ---------------");
		for(int i  = 4; i>= 0; i--) {
			num1.add(i);
			num3.add(i);
			num2.add(i*2);
			num4.add(i*2);
		}
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
		
		
		TreeSet<Integer> union = new TreeSet<Integer>(num1);
		TreeSet<Integer> intersection = new TreeSet<Integer>(num1);
		TreeSet<Integer> difference = new TreeSet<Integer>(num1);
		
		union.addAll(num2); //num1과 num2의 합집합 
		intersection.retainAll(num2); //num1과 num2의 교집합 
		difference.removeAll(num2); //num1과 num2의 차집합 
		System.out.println(union);
		System.out.println(intersection);
		System.out.println(difference);

		LinkedList<Integer> union1 = new LinkedList<Integer>(num3);
		LinkedList<Integer> intersection1 = new LinkedList<Integer>(num3);
		LinkedList<Integer> difference1 = new LinkedList<Integer>(num3);
		union1.addAll(num4);
		intersection1.retainAll(num4);
		difference.removeAll(num4);
		System.out.println(union1);
		System.out.println(intersection1);
		System.out.println(difference1);
		
	}

}
