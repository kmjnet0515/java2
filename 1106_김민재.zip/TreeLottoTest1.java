import java.util.Random;
import java.util.TreeSet;

public class TreeLottoTest1 {
    public static void main(String[] args){
        TreeSet<Integer> lottoSet = new TreeSet<Integer>();
        Random r = new Random();
        while(lottoSet.size() != 6){
            lottoSet.add(r.nextInt(45) + 1);
        }
        System.out.println(lottoSet);
        
    }
}
