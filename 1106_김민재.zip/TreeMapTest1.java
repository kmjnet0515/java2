import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapTest1 {
    public static void main(String[] args) {
        TreeMap<String, Integer> scores = new TreeMap<String,Integer>();
        scores.put("a",100);
        scores.put("b",90);
        scores.put("c",80);
        scores.put("d",70);
        scores.put("e",60);

        System.out.println("학생 성적 : ");
        //key를 기준으로 자동 정렬됨.
        for(Map.Entry<String, Integer> entry : scores.entrySet()){
            System.out.println("이름 : " + entry.getKey() + ", 성적 : " + entry.getValue());
        }
        /*
        Map.Entry<String, Integer> highest = scores.lastEntry();
        Map.Entry<String, Integer> lowest = scores.firstEntry();
        System.out.println("최고점수 : 이름 : " + highest.getKey() + ", 성적 : " + highest.getValue() + "\n최저점수 : 이름 : " + lowest.getKey() + ", 성적 : " + lowest.getValue());*/

        List<Map.Entry<String,Integer>> entryList = new ArrayList<>(scores.entrySet());
        entryList.sort(Comparator.comparingInt(Map.Entry::getValue));

        System.out.println("점수 순으로 출력(낮은 점수부터) : " + entryList.get(0));
        System.out.println("점수 순으로 출력(높은 점수부터) : " + entryList.get(entryList.size() - 1));
        System.out.println(entryList.get(0).getKey() + " : " + entryList.get(0).getValue());
    }
}
