import java.util.HashMap;
import java.util.Scanner;

public class HashMapTest1 {
    public static void main(String[] args) {
        HashMap<String, String> dict1 = new HashMap<String, String>();

        //3개의 (k,v) 쌍을 이루는 dict 만들기
        dict1.put("사과", "apple");
        dict1.put("바나나", "banana");
        dict1.put("오렌지" ,"orange");
        System.out.println(dict1);

        Scanner stdIn = new Scanner(System.in);

        while (true) {
            System.out.println("알고 싶은 과일 이름을 입력하세요.(0은 종료)");
            String kor = stdIn.next();
            if(kor.equals('0')){
                System.out.println("종료");
                break;
            }
            //HashMap에서 key의 value을 검색한다.
            String eng = dict1.get(kor);
            if(eng == null){
                System.out.println(kor + "은(는) 없는 단어입니다.");
            }
            else{
                System.out.println(eng);
            }
        }
    }
}
