package defaultpackage;

public class WrapperTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1 = 20;
		Integer num2 = Integer.valueOf(30);
		Integer num3 = 10; //자동호환 autoBoxing 
		//Interger(int) 생성자는 정수 값을 인수로 받아 Integer 객체로 생성한다.
	}

}
