package defaultpackage;

public class StringBufferTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SringBuffer : 문자열의 길이가 변할 수 있음. 
		StringBuffer sb1 = new StringBuffer("Hello JAVA");
		StringBuffer sb2 = new StringBuffer("처음 시작하는 자바");
		System.out.println("sb1 내용 : " + sb1);
		System.out.println("sb2 내용 : " + sb2);
		//문자열 삽입 
		System.out.println("문자열 끼워넣기 : " + sb2.insert(8, "Power "));
		//문자 대체 
		sb2.setCharAt(5, 'd');
		System.out.println("문자 바꾸기 : " + sb2);
		//문자의 길이 지정 
		sb2.setLength(5);
		System.out.println("문자 바꾸기 : " + sb2);

	}

}
