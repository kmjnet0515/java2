package defaultpackage;

import java.util.Scanner;

public class isLetter {
	public boolean isLet(String s) {
		for(int i = 0; i<s.length(); i++) {
			if(!(s.charAt(i) >= 48 && s.charAt(i) <= 57)) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.print("문자 또는 숫자를 입력 : ");
		String input = stdIn.next();
		
		boolean letter = false;
		for(int i = 0; i<input.length(); i++) {
			char c = input.charAt(i);
			if(Character.isLetter(c)) {
				letter = true;
				break;
			}
		}
		if(letter) {
			System.out.println(input + "은 문자입니다.");
		}
		else {
			System.out.println(input + "은 숫자입니다.");
		}
		isLetter i = new isLetter();
		System.out.println(i.isLet(input));
	}
}
