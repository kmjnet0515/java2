import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
class EventClass2 implements ActionListener{
	private ImageIcon img1;
	private JLabel jl;
	public EventClass2(ImageIcon img1, JLabel jl) {
		this.img1 = img1;
		this.jl = jl;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		jl.setText(e.getActionCommand());
		jl.setIcon(img1);
	}
	
}
class JLabel1 extends JFrame{
	private JLabel result = new JLabel();
	public ImageIcon img1, img2;
	public JLabel1() {
		Container ct1 = getContentPane();
		//컨테이너 생성 
		ct1.setLayout(new FlowLayout());
		//버튼 생성
		JButton jb1 = new JButton("사과");
		JButton jb2 = new JButton("배");
		
		
		img1 = new ImageIcon("image/apple.jpg");
		img2 = new ImageIcon("image/pear.jpg");
		
		jb1.addActionListener(new EventClass2(img1, result));
		jb2.addActionListener(new EventClass2(img2, result));
		
		ct1.add(jb1);
		ct1.add(jb2);
		ct1.add(result);
		
		setTitle("jLabel");
		
		setSize(300, 300);
		
		//윈도우 창 종료시 프로세스 닫기 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
	}
	
}
public class JLabelTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JLabel1();
	}

}
