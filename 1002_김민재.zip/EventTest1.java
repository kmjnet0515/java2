import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
//GUI 클래스

/*
 * GUI 클래스에 이벤트 처리
 * GUI 클래스 
 * 1) 처리할 이벤트 종류 결정.
 * 2) 이벤트에 적합한 이벤트 리스너 인터페이스 사용. 
 */
class Event1 extends JFrame implements ActionListener{
	JLabel jl;
	public Event1(){
		Container ct1 = getContentPane();
		FlowLayout FL1 = new FlowLayout();
		ct1.setLayout(FL1);
		jl = new JLabel("버튼을 누르세요.");
		
		JButton jb1 = new JButton("버튼");
		//3) 이벤트를 받아 들일 버튼에 리스너 등록 
		jb1.addActionListener(this);
		ct1.add(jb1);
		ct1.add(jl);
		
		setTitle("Event 테스트");
		
		setSize(400, 300);
		
		//윈도우 창 종료시 프로세스 닫기 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
	}
	//4) 리스너 인터페이스에 선언된 메소드를 오버라이딩하여 이벤트 처리 루틴 작성. 
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		jl.setText("안녕하세요. ");
	}
}
//메인 클래스 
public class EventTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Event1();
	}

}
