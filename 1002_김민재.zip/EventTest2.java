import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
//GUI 클래스

/*
 * GUI 클래스에 이벤트 처리
 * GUI 클래스 
 * 1) 처리할 이벤트 종류 결정.
 * 2) 이벤트에 적합한 이벤트 리스너 인터페이스 사용. 
 */
class Event2 extends JFrame{
	JLabel jl;
	public Event2(){
		Container ct1 = getContentPane();
		FlowLayout FL1 = new FlowLayout();
		ct1.setLayout(FL1);
		jl = new JLabel("버튼을 누르세요.");
	    
		JButton jb1 = new JButton("사랑합니다. ");
		JButton jb2 = new JButton("행복합니다. ");
		//3) 이벤트를 받아 들일 버튼에 리스너 등록 
		jb1.addActionListener(new EventProcess());
		jb2.addActionListener(new EventProcess());

		ct1.add(jb1);
		ct1.add(jb2);
		ct1.add(jl);
		
		setTitle("Event 테스트2");
		
		setSize(300, 300);
		
		//윈도우 창 종료시 프로세스 닫기 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
	}
	//4) 리스너 인터페이스에 선언된 메소드를 오버라이딩하여 이벤트 처리 루틴 작성. 
	private class EventProcess implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			//버튼의 레이블을 문자열로 변환시킴. 
			jl.setText(e.getActionCommand());
		}	
	}
	
}
//메인 클래스 
public class EventTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Event2();
	}

}
