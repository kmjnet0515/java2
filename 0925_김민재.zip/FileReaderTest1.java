import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileReaderTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.println("읽어올 파일 명을 입력하세요. : ");
		String s = stdIn.next() + ".txt";
		try {
			FileReader fr = new FileReader(s);
			int i;
			while ((i = fr.read()) != -1) {
				System.out.print((char)i);
			}
			fr.close();
		}
		catch(FileNotFoundException e) {
			System.out.println("파일이 없습니다. ");
		}
		catch(IOException e) {
			System.out.println("파일이 없습니다.");
		}
	}

}
