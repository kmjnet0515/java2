import java.io.IOException;
import java.io.InputStream;

public class SystemIn01 {

	public static void main(String[] args) {
		System.out.print("데이터 입력 : ");
		InputStream is = System.in; // byte 타입을 처리하는 것이다.
		try {
			int data = is.read(); //값 읽어오기. 가장 첫번째 값만 해석된다.  read는 1바이트의 값만 읽을 수 있다. -> 한글은 제대로 출력되지 않는다. 
			System.out.println((char)data + " " + data);
			is.close();
		}
		catch(IOException e) {
			System.out.println(e);
		}
		
	}

}
