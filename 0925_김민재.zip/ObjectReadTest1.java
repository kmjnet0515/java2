import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

public class ObjectReadTest1 {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.print("불러올 파일명을 입력하세요 : ");
		String s = stdIn.next();
		
		//객체를 읽어 올 수 있는 ois 객체 생성. 
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(s));
			Object s2 = ois.readObject();
			
			//readObject() 메소드로 직렬화된 객체의 2진 데이터를 읽어서 객체 타입으로 형변환한다. 
			PersonInfo p1 = (PersonInfo)ois.readObject();
			PersonInfo p2 = (PersonInfo)ois.readObject();
			System.out.println(s2);
			System.out.println(p1.name + p1.city + p1.age);
			System.out.println(p2.name + p2.city + p2.age);

		} catch (FileNotFoundException e){
			System.out.println(s + "파일이 없습니다.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(s + "파일이 없습니다.");
		} 
	}

}
