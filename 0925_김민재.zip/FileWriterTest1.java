import java.io.FileWriter;
import java.util.Scanner;

public class FileWriterTest1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		String source = "asdf";
		System.out.print("저장할 파일을 입력하세요. : ");
		String s = stdIn.next() + ".txt";
		//저장한 파일명으로 객체 생성 
		try {
			FileWriter fw = new FileWriter(s);
			fw.write(source);
			fw.close();
			System.out.println("파일이 생성되었습니다. ");
		}
		catch(Exception e){
			System.out.println(e);
			
		}
	}

}
