import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class SystemIn02 {

	public static void main(String[] args) {
		System.out.print("데이터 입력 : ");
		InputStream is = System.in; // byte 타입을 처리하는 것이다.
		//한글 처리를 위해 문자기반 스트림 사용. 
		InputStreamReader isr = new InputStreamReader(is); 
		BufferedReader br = new BufferedReader(isr);
		try {
			String data = br.readLine(); //값 읽어오기. 가장 첫번째 값만 해석된다.  read는 1바이트의 값만 읽을 수 있다. -> 한글은 제대로 출력되지 않는다. 
			System.out.println(data);
			is.close();
		}
		catch(IOException e) {
			System.out.println(e);
		}
		
	}

}
