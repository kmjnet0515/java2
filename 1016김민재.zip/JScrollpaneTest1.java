import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

class JScrollPane1 extends JFrame{
	public JScrollPane1() {
		Container ct = getContentPane();
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout(20,5));
		for(int i = 0; i < 100; i++) {
			jp.add(new Button("" + i));
		}
		//가로, 세로 스크롤 생성. 
		int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
		int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
		
		//스크롤 팬 생성.
		JScrollPane jsp = new JScrollPane(jp,v,h);
		
		//컨테이너에 추가. - BorderLayout의 가운데에 넣기 
		ct.add(jsp, BorderLayout.CENTER);
		
		
		
		
		setTitle("JScrollPane");
		
		setSize(300,300);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
	}
}
public class JScrollpaneTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JScrollPane1();
	}

}
