import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
class RadioPanel1 extends JPanel implements ActionListener{
	

	ButtonGroup gb = new ButtonGroup();//버튼끼리 묶어야함. 
	
	JLabel jl1 = new JLabel("당신의 성별을? ");
	JLabel jl2 = new JLabel("");
	
	JRadioButton[] jr = new JRadioButton[5];
	String[] gender = {"남자", "여자"};
	
	public RadioPanel1() {
		for(int i = 0; i<2; i++) {
			jr[i] = new JRadioButton(gender[i]);
			jr[i].addActionListener(this);
			//성별 판넬에 객체 추가. 
			gb.add(jr[i]);
			//성별 판넬에 객체 추가. 
			add(jr[i]);
		}
		add(jl1);
		add(jl2);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		jl2.setText(e.getActionCommand());
	}
}

class ComboPanel1 extends JPanel implements ItemListener{
	

	JLabel jl1 = new JLabel("당신의 혈액형은? ");
	JLabel jl2 = new JLabel("");
	
	public ComboPanel1() {
		JComboBox<String> jcb = new JComboBox<String>();
		jcb.addItem("A");
		jcb.addItem("B");
		jcb.addItem("AB");
		jcb.addItem("O");
		
		add(jl1);
		add(jl2);
		add(jcb);
		jcb.addItemListener(this);
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		jl2.setText(e.getItem().toString());
	}
}
class JTabbedPane1 extends JFrame{
	public JTabbedPane1() {
		Container ct = getContentPane();
		JTabbedPane jtp = new JTabbedPane();
				
		RadioPanel1 rb1 = new RadioPanel1();
		ComboPanel1 cp1 = new ComboPanel1();
		
		jtp.addTab("성별", rb1);
		jtp.addTab("혈액형", cp1);

		ct.add(jtp);
		
		setTitle("JTabbedPaneTest");
		
		setSize(300,300);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
	}
}
public class JTabbedPaneTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JTabbedPane1();
	}

}
