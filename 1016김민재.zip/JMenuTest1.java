import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextField;

class JMenu1 extends JFrame implements ActionListener{
	
	JTextField jtf;
	public JMenu1() {
		Container ct1 = getContentPane();
		ct1.setLayout(new BorderLayout());
		
		//1. JMenuBar() 객체 생성. 
		JMenuBar jmb = new JMenuBar();
		
		//2. JMenu 객체 생성. 
		JMenu jm1 = new JMenu("파일"); //새파일 저장 
		JMenu jm2 = new JMenu("편집"); //열기 잘라내기 복사 눈금자 수정 가능상태 
		
		//3. JMemuTiem 객체 생성 
		JMenuItem jmi = new JMenuItem("새파일");
		jmi.addActionListener(this);
		jm1.add(jmi);
		
		jmi = new JMenuItem("저장");
		jmi.addActionListener(this);
		jm1.add(jmi);
		
		
		
		jmi = new JMenuItem("열기");
		jmi.addActionListener(this);
		jm2.add(jmi);

		jmi = new JMenuItem("잘라내기");
		jmi.addActionListener(this);
		jm2.add(jmi);

		jmi = new JMenuItem("복사");
		jmi.addActionListener(this);
		jm2.add(jmi);

		JCheckBoxMenuItem jcbmi = new JCheckBoxMenuItem("눈금자");
		jcbmi.addActionListener(this);
		jm2.add(jcbmi);

		JRadioButtonMenuItem jrbmi = new JRadioButtonMenuItem("수정가능상태");
		jrbmi.addActionListener(this);
		jm2.add(jrbmi);
		
		//4 메뉴바에 메뉴 추가하기 
		jmb.add(jm1);
		jmb.add(jm2);
		
		//5 setJMenuBar()메소드로 메뉴바를 프레임에 추가. 
		setJMenuBar(jmb);
		
		jtf = new JTextField();
		ct1.add(jtf, BorderLayout.SOUTH);
		
		setTitle("JButton에 아이콘 씌우기. ");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		jtf.setText(e.getActionCommand());
	}
}
public class JMenuTest1 {
	public static void main(String[] args) {
		new JMenu1();
	}
}
