import java.awt.GridLayout;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;

class GridLayout1 extends JFrame{
	public GridLayout1(){
		//프레임으로부터 컨테이너 생성. 
		Container ct = getContentPane();
		
		//배치 관리자 객체 생성. 
		GridLayout gl = new GridLayout(4,5,10,10);
		//컨테이너에 레이아웃 설정. 
		ct.setLayout(gl);
		
		//5개 버튼을 생성하여 컨테이너에 배치 
		for(int i = 1; i<=20; i++) {
			ct.add(new JButton("버튼" + i));
		}
		setTitle("GridLayoutTest1");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setSize(500,500);
		
		setVisible(true);
	}
}
public class GridLayoutTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GridLayout1();
	}

}
