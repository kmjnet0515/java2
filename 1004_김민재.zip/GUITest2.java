import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.FileInputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class EventClass6 implements ActionListener{
	JTextField jtf;
	JTextArea jta;
	public EventClass6(JTextField jtf, JTextArea jta) {
		this.jtf = jtf;
		this.jta = jta;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			FileInputStream fis = new FileInputStream(jtf.getText());
			DataInputStream dis = new DataInputStream(fis);
			
			jta.setText(dis.readUTF());
			fis.close();
			System.out.println(jtf.getText() + "파일을 읽었습니다. ");
			/*
			int t;
			String s = "";
			while((t = fis.read()) != -1) {
				s += (char)t;
			}
			jta.setText(s);
			*/
		}
		catch(Exception e1){
			System.out.println(e1);
		}
	}
	
}

class JButton4 extends JFrame{
	public JButton4() {
		Container ct1 = getContentPane();
		ct1.setLayout(new FlowLayout());
		JTextField jtf = new JTextField("파일 이름을 입력하세요. ", 20);
		//버튼객체생성. 
		JButton jb1 = new JButton("파일로 저장");

		JTextArea jta = new JTextArea(10,20);
		jta.setEditable(false);
		
		ct1.add(jtf);
		ct1.add(jb1);
		ct1.add(jta);
		
		jb1.addActionListener(new EventClass6(jtf, jta));
		
		
		
		setTitle("파일로 저장하는 GUI");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setVisible(true);
		
	}
}
public class GUITest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JButton4();
	}

}
