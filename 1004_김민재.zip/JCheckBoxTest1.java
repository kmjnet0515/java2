import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JTextField;

class EventClass7 implements ItemListener{
	JTextField languageTF;
	public EventClass7(JTextField languageTf) {
		this.languageTF = languageTf;
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		languageTF.setText(((JCheckBox)e.getItem()).getText());

	}
}
class JCheckBox1 extends JFrame{
	public JCheckBox1() {
		Container ct1 = getContentPane();
		ct1.setLayout(new FlowLayout());
		JTextField languageTF = new JTextField(10);
		
		JCheckBox language1 = new JCheckBox("JAVA");
		JCheckBox language2 = new JCheckBox("JSP");
		JCheckBox language3 = new JCheckBox("Python");
		JCheckBox language4 = new JCheckBox("C");

		//컨테이너에 체크박스 추가
		ct1.add(language1);
		ct1.add(language2);
		ct1.add(language3);
		ct1.add(language4);
		ct1.add(languageTF);
		
		language1.addItemListener(new EventClass7(languageTF));
		language2.addItemListener(new EventClass7(languageTF));
		language3.addItemListener(new EventClass7(languageTF));
		language4.addItemListener(new EventClass7(languageTF));

		setTitle("checkbox");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setVisible(true);
	}
}
public class JCheckBoxTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JCheckBox1();
	}

}
