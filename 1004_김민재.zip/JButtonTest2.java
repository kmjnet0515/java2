import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

class EventClass4 implements ActionListener{
	JTextField jtf;
	public EventClass4(JTextField jtf) {
		this.jtf = jtf;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		jtf.setText(e.getActionCommand());
		
	}
	
}

class JButton2 extends JFrame{
	public JButton2() {
		Container ct1 = getContentPane();
		GridLayout gl = new GridLayout(3,2,10,10);
		JTextField jtf = new JTextField(10);
		//버튼객체생성. 
		JButton jb1 = new JButton("사과", new ImageIcon("image/apple.jpg"));
		JButton jb2 = new JButton("바나나", new ImageIcon("image/banana.jpg"));
		JButton jb3 = new JButton("체리", new ImageIcon("image/cherry.jpg"));
		JButton jb4 = new JButton("배", new ImageIcon("image/pear.jpg"));
		JButton jb5 = new JButton("포도", new ImageIcon("image/grape.jpg"));

		
		ct1.setLayout(gl);
		
		ct1.add(jb1);
		ct1.add(jb2);
		ct1.add(jb3);
		ct1.add(jb4);
		ct1.add(jb5);
		
		jb1.addActionListener(new EventClass4(jtf));
		jb2.addActionListener(new EventClass4(jtf));
		jb3.addActionListener(new EventClass4(jtf));
		jb4.addActionListener(new EventClass4(jtf));
		jb5.addActionListener(new EventClass4(jtf));
		
		
		
		ct1.add(jtf);
		setTitle("JButton에 아이콘 씌우기. ");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setVisible(true);
		
	}
}
public class JButtonTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JButton2();
	}

}
