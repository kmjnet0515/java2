import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.FileOutputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class EventClass5 implements ActionListener{
	JTextField jtf;
	JTextArea jta;
	public EventClass5(JTextField jtf, JTextArea jta) {
		this.jtf = jtf;
		this.jta = jta;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			FileOutputStream fos = new FileOutputStream(jtf.getText());
			DataOutputStream dos = new DataOutputStream(fos);
			dos.writeUTF(jta.getText());
			fos.close();
			/*
			String s1 = jta.getText();
			for(int i = 0; i<s1.length(); i++) {
				fos.write(s1.charAt(i));
			}
			*/
			fos.close();
			System.out.println(jtf.getText() + "파일명으로 바이트 파일 생성 완료");
		}
		catch(Exception e1){
			System.out.println(e1);
		}
	}
	
}

class JButton3 extends JFrame{
	public JButton3() {
		Container ct1 = getContentPane();
		ct1.setLayout(new FlowLayout());
		JTextField jtf = new JTextField(20);
		JLabel jl = new JLabel("파일이 존재합니다.");
		//버튼객체생성. 
		JButton jb1 = new JButton("파일로 저장");
		JButton jb2 = new JButton("덮어쓰기");
		JButton jb3 = new JButton("취소");
		JTextArea jta = new JTextArea(10,20);
		
		ct1.add(jtf);
		ct1.add(jb1);
		ct1.add(jta);
		
		jb1.addActionListener(new EventClass5(jtf, jta));
		
		
		
		setTitle("파일로 저장하는 GUI");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setVisible(true);
		
	}
}
public class GUITest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JButton3();
	}

}
