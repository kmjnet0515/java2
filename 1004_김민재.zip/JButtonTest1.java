import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
/*
class EventClass3 implements ActionListener{
	JButton jb1;
	ImageIcon img1;
	public EventClass3(JButton jb1, ImageIcon img1) {
		this.jb1 = jb1;
		this.img1 = img1;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}
	
}
*/
class JButton1 extends JFrame{
	public JButton1() {
		Container ct1 = getContentPane();
		ImageIcon korea = new ImageIcon("image/korea1.gif");
		ImageIcon Usa = new ImageIcon("image/usa.gif");
		ImageIcon Germany = new ImageIcon("image/germany.gif");
		
		//버튼객체생성. 
		JButton nat = new JButton(korea);
		nat.setPressedIcon(korea);//기본 
		nat.setPressedIcon(Usa);//버튼누르면 미국 국기  
		nat.setRolloverIcon(Germany); //버튼에 마우스 올리면 독일 국기. 
		ct1.add(nat);
		
		setTitle("JButton에 아이콘 씌우기. ");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setVisible(true);
		
	}
}
public class JButtonTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JButton1();
	}

}
