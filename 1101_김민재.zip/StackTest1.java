import java.util.Scanner;
import java.util.Stack;

public class StackTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> stack = new Stack<String>();
		
		//키보드로부터 4개의 과일 이름을 입력받아 stack에 저장.
		Scanner stdIn = new Scanner(System.in);
		System.out.print("과일 이름을 입력하세요. : ");
		for(int i = 0 ;i < 4; i++)
			stack.push(stdIn.next());
		System.out.println(stack);
		/*
		for(int i = 0; i<4; i++) {
			System.out.println(stack.pop());
		}*/
		
		System.out.print("찾고 싶은 과일 이름 입력 : ");
		String f_name = stdIn.next();
		int fruit = stack.search(f_name);
		if(fruit != -1)
			System.out.println(f_name + "의 위치는 : " + fruit);
		else
			System.out.println("없더ㅏ");
		
		System.out.print("스택 삭제 : ");
		while(!stack.empty())
			System.out.println(stack.pop());
		
	}

}
