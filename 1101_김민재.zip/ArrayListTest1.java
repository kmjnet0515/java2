import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class ArrayListTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//문자열 배열 생성. 
		String[] name = {"kim" ,"lee", "park", "jung", "oh"};
		
		//문자열의 배열을 이용하여 리스트 객체(제네릭) 생성. 
		ArrayList<String> lName = new ArrayList<String>(Arrays.asList(name));
		System.out.println("초기값 : " + lName);
		System.out.println(lName.get(0));
		//추가 
		lName.add("ha");
		System.out.println(lName.get(lName.size() -1));
		
		//김으로 변경 
		lName.set(0,  "김");
		System.out.println("0번지 김으로 변경 " + lName);
		
		lName.add(3,"곽");
		System.out.println("3번지 곽으로 추가 " + lName);

		//컬렉션 클래스의 메소드 활용 - 무작위 재배열 
		Collections.shuffle(lName);
		System.out.println("무작위 재배열 " + lName);

		//리스트 정렬 
		Collections.sort(lName);
		System.out.println("리스트 정렬 " + lName);

		//리스트의 모든 요소를 "김"으로 채우기. 
		Collections.fill(lName, "김");
		System.out.println("모두 \'김\'채우기 " + lName);

	}

}
