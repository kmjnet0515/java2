import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

class Lotto extends JFrame implements ActionListener{
	
	JButton jb1;
	JLabel jl;
	public Lotto() {
		Container ct = getContentPane();
		JPanel jp = new JPanel();
		jb1 = new JButton("로또 추첨기");
		jp.add(jb1);
		jb1.addActionListener(this);
		
		JPanel jp2 = new JPanel();
		jl = new JLabel("로또 번호 : ");
		jp2.add(jl);
		
		ct.setLayout(new GridLayout(2,1));
		ct.add(jp);
		ct.add(jp2);
		
		
		setTitle("checkbox");
		
		setSize(400,400);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Random r1 = new Random();
		int[] array1 = new int[6];
		int index = 0;
		first : while(index < 6) {
			int number = Math.abs(r1.nextInt())%44 + 1;
			for(int i = 0; i < index; i++) {
				if(array1[i] == number) {
					continue first;
				}
			}
			array1[index++] = number;
		}
		Arrays.sort(array1);
		jl.setText(Arrays.toString(array1));
	}
}
public class LottoNumGUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Lotto();
	}

}
