import java.util.Scanner;

public class ScannerTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String day = "happy day, smile day, nice day, joyful day, ";
		Scanner stdIn = new Scanner(day);
		stdIn.useDelimiter(" day, "); //분리자 지정 
		while(stdIn.hasNext()) {
			System.out.println(stdIn.next() + "!");
		}
	}

}
