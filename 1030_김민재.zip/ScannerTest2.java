import java.io.File;
import java.util.Scanner;

public class ScannerTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.print("검색을 원하는 학생의 학번을 입력하시오 : ");
		try {
			int id = stdIn.nextInt();
			Scanner idNum = new Scanner(new File("phone.txt"));
			while(idNum.hasNext()) {
				if(id == idNum.nextInt()) {
					System.out.println(id + "학생의 전화번호는 " + idNum.next());
					return;
				}
				else {
					idNum.next();
				}
			}
			System.out.println("해당 학생 전화번호가 없습니다.");
		}
		catch(Exception e) {
			System.out.println(e);
		}		
	}

}
